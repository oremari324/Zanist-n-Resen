import { useState, useEffect, useRef } from "react";
import ReactMarkdown from "react-markdown";
import { motion, AnimatePresence } from "motion/react";
import {
  BookOpen,
  Calculator,
  Atom,
  Beaker,
  Sparkles,
  Upload,
  Trash2,
  Volume2,
  VolumeX,
  Copy,
  Check,
  RotateCcw,
  History,
  Send,
  HelpCircle,
  Plus,
  BookMarked,
  Info,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  Search,
  CheckCircle,
  GraduationCap,
  Camera,
  Sun,
  Moon,
} from "lucide-react";
import {
  MATH_PRESETS,
  PHYSICS_PRESETS,
  CHEMISTRY_PRESETS,
  MATH_KEYPAD_SYMBOLS,
  PHYSICAL_CONSTANTS,
  CHEMICAL_ELEMENTS,
  type Preset,
  type PhysicalConstant,
  type ChemicalElement,
} from "./data";

interface HistoryItem {
  id: string;
  subject: "math" | "physics" | "chemistry";
  prompt: string;
  solution: string;
  timestamp: number;
  image?: string; // Base64 representation for preview
}

interface ChatMessage {
  role: "user" | "assistant";
  text: string;
}

export default function App() {
  const [subject, setSubject] = useState<"math" | "physics" | "chemistry">("math");
  const [prompt, setPrompt] = useState("");
  const [loading, setLoading] = useState(false);
  const [solution, setSolution] = useState<string | null>(null);
  
  // Image Upload State
  const [image, setImage] = useState<string | null>(null);
  const [imageMimeType, setImageMimeType] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  // History & Sidebar States
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");

  // Conversational Follow-up State
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [followUpText, setFollowUpText] = useState("");
  const [chatLoading, setChatLoading] = useState(false);

  // Copy/Speech Feedback States
  const [copied, setCopied] = useState(false);
  const [speaking, setSpeaking] = useState(false);

  // Dark Mode State
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem("academic_assistant_dark_mode");
    return saved ? saved === "true" : true; // Default to dark mode!
  });

  useEffect(() => {
    localStorage.setItem("academic_assistant_dark_mode", String(darkMode));
    if (darkMode) {
      document.documentElement.classList.add("dark");
      document.body.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
      document.body.classList.remove("dark");
    }
  }, [darkMode]);
  
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const workspaceRef = useRef<HTMLDivElement>(null);

  // Load history on mount
  useEffect(() => {
    const saved = localStorage.getItem("academic_assistant_history");
    if (saved) {
      try {
        setHistory(JSON.parse(saved));
      } catch (e) {
        console.error("Error loading history", e);
      }
    }
  }, []);

  // Scroll to bottom of chat when it updates
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, chatLoading]);

  // Save history helper
  const saveToHistory = (newSolution: string, queryPrompt: string, base64Img: string | null) => {
    const newItem: HistoryItem = {
      id: crypto.randomUUID(),
      subject,
      prompt: queryPrompt,
      solution: newSolution,
      timestamp: Date.now(),
      image: base64Img || undefined,
    };
    const updated = [newItem, ...history].slice(0, 50); // Keep last 50 items
    setHistory(updated);
    localStorage.setItem("academic_assistant_history", JSON.stringify(updated));
  };

  // Clear history helper
  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem("academic_assistant_history");
  };

  // Cursor symbol insertion helper
  const insertSymbol = (symbol: string) => {
    if (!textareaRef.current) {
      setPrompt((prev) => prev + symbol);
      return;
    }
    const start = textareaRef.current.selectionStart;
    const end = textareaRef.current.selectionEnd;
    const text = textareaRef.current.value;
    const before = text.substring(0, start);
    const after = text.substring(end, text.length);
    setPrompt(before + symbol + after);
    
    setTimeout(() => {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.selectionStart = textareaRef.current.selectionEnd = start + symbol.length;
      }
    }, 0);
  };

  // Handle Drag & Drop for Images
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const processFile = (file: File) => {
    if (!file.type.startsWith("image/")) {
      alert("هیڤییە تەنێ فایلێن وێنەیی ل بار بکە");
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => {
      if (reader.result) {
        setImage(reader.result.toString().split(",")[1]); // Extract base64 part
        setImageMimeType(file.type);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      processFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      processFile(e.target.files[0]);
    }
  };

  const removeImage = () => {
    setImage(null);
    setImageMimeType(null);
  };

  // Submit main problem
  const handleSolve = async () => {
    if (!prompt.trim() && !image) {
      alert("هیڤییە کێشەیەک بنڤیسە یان وێنەیەک ل بار بکە بەری چارەسەرکرنێ");
      return;
    }

    setLoading(true);
    setSolution(null);
    setChatHistory([]); // Reset follow-up chat
    
    try {
      const response = await fetch("/api/solve", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt,
          subject,
          image,
          mimeType: imageMimeType,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setSolution(data.solution);
        saveToHistory(data.solution, prompt || `شیکارکرنا وێنەی (${subject})`, image);
      } else {
        alert(data.error || "خەلەتیەک چێبوو د دەمێ وەرگرتنا بەرسڤێ دا");
      }
    } catch (error) {
      console.error("Fetch error:", error);
      alert("پەیوەندی دگەل سێرڤەری نەهاتە گرێدان. هیڤییە دووبارە هەول بدە.");
    } finally {
      setLoading(false);
    }
  };

  // Submit follow-up question
  const handleFollowUp = async () => {
    if (!followUpText.trim() || !solution) return;

    const userMsg = followUpText;
    setChatHistory((prev) => [...prev, { role: "user", text: userMsg }]);
    setFollowUpText("");
    setChatLoading(true);

    try {
      const contextPrompt = `ئەڤە بەرسڤ یان شلوڤەکرنا بەری نوکەیە:
${solution}

پرسیارا قوتابی ل سەر ڤێ شلوڤەکرنێ ئەڤەیە:
"${userMsg}"

تکایە ب شێوازەکێ کورت و زانستی و روون ب زمانێ کوردی زاراڤێ بەهدینی یێ پەتی بەرسڤا پرسیارێ بدە. ئەگەر پرسیار ب بیرکاری یان هاوکێشەیان ڤە گرێدایی بیت، هاوکێشەیان ب شێوازێ ستاندارد بنڤیسە.`;

      const response = await fetch("/api/solve", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          prompt: contextPrompt,
          subject,
        }),
      });

      const data = await response.json();
      if (response.ok) {
        setChatHistory((prev) => [...prev, { role: "assistant", text: data.solution }]);
      } else {
        setChatHistory((prev) => [
          ...prev,
          { role: "assistant", text: "ببورە، من نەشیا ب باشی بەرسڤا پرسیارێ بدەم. هیڤییە دووبارە هەول بدە." },
        ]);
      }
    } catch (e) {
      console.error(e);
      setChatHistory((prev) => [
        ...prev,
        { role: "assistant", text: "ببورە، خەلەتیەک چێبوو د پەیوەندیکرنێ دا دگەل سیستەمی." },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  // Reset the active solver screen
  const handleReset = () => {
    setPrompt("");
    setSolution(null);
    setImage(null);
    setImageMimeType(null);
    setChatHistory([]);
  };

  // Select category with auto-scroll and focus
  const handleCategorySelect = (category: string, subjectKey: "math" | "physics" | "chemistry") => {
    setSubject(subjectKey);
    handleReset();
    
    console.log(`تو یێ ل سەر بابەتێ: ${category} کار دکەی.`);
    
    setTimeout(() => {
      const inputArea = document.getElementById("input-area");
      if (inputArea) {
        inputArea.scrollIntoView({ behavior: "smooth", block: "center" });
        inputArea.focus();
      }
    }, 100);
  };

  // Select a preset query
  const handlePresetSelect = (preset: Preset) => {
    setPrompt(preset.prompt);
    setTimeout(() => {
      textareaRef.current?.focus();
      workspaceRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  // Load an item from history
  const handleLoadHistory = (item: HistoryItem) => {
    setSubject(item.subject);
    setPrompt(item.prompt);
    setSolution(item.solution);
    if (item.image) {
      setImage(item.image);
      setImageMimeType("image/png");
    } else {
      setImage(null);
      setImageMimeType(null);
    }
    setChatHistory([]);
    setTimeout(() => {
      workspaceRef.current?.scrollIntoView({ behavior: "smooth" });
    }, 100);
  };

  // Copy Solution to Clipboard
  const handleCopy = () => {
    if (!solution) return;
    navigator.clipboard.writeText(solution);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Speak solution out loud in Kurdish context
  const handleSpeak = () => {
    if (!solution) return;
    if (speaking) {
      window.speechSynthesis.cancel();
      setSpeaking(false);
      return;
    }

    const cleanText = solution
      .replace(/[*#`_\-]/g, "")
      .replace(/\\int/g, "تەواوکاری")
      .replace(/\\sqrt/g, "ڕەگی دووەمی")
      .replace(/\+/g, " زێدەباری ")
      .replace(/=/g, " یەکسانە بە ");

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = "ku-IQ";
    
    const voices = window.speechSynthesis.getVoices();
    const midEastVoice = voices.find((v) => v.lang.startsWith("ar") || v.lang.startsWith("tr"));
    if (midEastVoice) utterance.voice = midEastVoice;

    utterance.onend = () => setSpeaking(false);
    utterance.onerror = () => setSpeaking(false);
    
    setSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const getPresets = () => {
    if (subject === "math") return MATH_PRESETS;
    if (subject === "physics") return PHYSICS_PRESETS;
    return CHEMISTRY_PRESETS;
  };

  // Filter history based on search query
  const filteredHistory = history.filter(item => 
    item.prompt.toLowerCase().includes(searchQuery.toLowerCase()) ||
    item.solution.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className={`min-h-screen transition-colors duration-300 flex flex-col font-sans ${darkMode ? "bg-zinc-950 text-zinc-100" : "bg-slate-50 text-slate-800"}`} dir="rtl">
      
      {/* Sleek Navigation Bar */}
      <nav className={`w-full h-16 border-b px-4 sm:px-8 flex items-center justify-between shadow-xs sticky top-0 z-40 transition-colors duration-300 ${
        darkMode ? "bg-zinc-900/95 border-zinc-800/80" : "bg-white border-slate-200"
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center text-white font-black text-lg shadow-sm shadow-indigo-150">
            ZR
          </div>
          <div className="flex flex-col text-right">
            <span className={`text-base sm:text-lg font-bold tracking-tight ${darkMode ? "text-white" : "text-slate-800"}`}>زانستێن رەسەن</span>
            <span className="text-[10px] text-slate-400 font-semibold -mt-1">هاریکارێ تە یێ ئەکادیمی</span>
          </div>
        </div>

        {/* Dynamic Nav Search Box to search through previous solutions/questions */}
        <div className="flex-1 max-w-sm sm:max-w-md mx-4 sm:mx-12 relative hidden sm:block">
          <div className="relative">
            <input
              type="text"
              placeholder="ل هەر بابەت یان کێشەکا دەربازبووی بگەرە..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className={`w-full border-none rounded-full py-2.5 pr-10 pl-4 text-xs focus:ring-2 focus:ring-indigo-500 text-right outline-none transition-all duration-200 ${
                darkMode ? "bg-zinc-800/60 text-zinc-100 placeholder:text-zinc-500" : "bg-slate-100 text-slate-800 placeholder:text-slate-400"
              }`}
              dir="rtl"
            />
            <div className="absolute right-3.5 top-3 text-slate-400 pointer-events-none">
              <Search className="w-4 h-4" />
            </div>
            {searchQuery && (
              <button 
                onClick={() => setSearchQuery("")} 
                className="absolute left-3.5 top-2.5 text-xs text-slate-400 hover:text-slate-600"
              >
                پاککرنەوە
              </button>
            )}
          </div>
        </div>

        {/* User profile & theme switcher matching design theme */}
        <div className="flex items-center gap-3">
          {/* Theme switcher */}
          <button
            onClick={() => setDarkMode(!darkMode)}
            className={`p-2 rounded-xl border transition-all duration-200 hover:scale-[1.05] cursor-pointer ${
              darkMode 
                ? "bg-zinc-800 border-zinc-700 text-yellow-400 hover:bg-zinc-700" 
                : "bg-slate-100 border-slate-200 text-indigo-600 hover:bg-slate-200"
            }`}
            title={darkMode ? "دیزاینێ روون" : "دیزاینێ تاری"}
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          <div className="text-right hidden md:block">
            <p className={`text-xs sm:text-sm font-bold ${darkMode ? "text-zinc-200" : "text-slate-700"}`}>ئەحمەد محەمەد</p>
            <p className="text-[10px] text-slate-400 font-medium">قوتابیێ زانستی</p>
          </div>
          <div className={`w-10 h-10 rounded-full border-2 shadow-xs overflow-hidden flex items-center justify-center font-bold text-xs ${
            darkMode ? "bg-zinc-800 border-zinc-700 text-indigo-400" : "bg-indigo-50 border-white text-indigo-600"
          }`}>
            ئ م
          </div>
        </div>
      </nav>

      {/* Main Layout containing Sidebar and Core Workspace */}
      <main className="flex-1 grid grid-cols-12 gap-6 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full">
        
        {/* Left Sidebar: Recent Activity & Sleek Gamified Progress */}
        <aside className="col-span-12 lg:col-span-3 flex flex-col gap-6 order-2 lg:order-1">
          
          {/* Recent Activity Card */}
          <div className={`rounded-3xl p-5 shadow-xs border flex flex-col min-h-[300px] lg:flex-1 transition-colors duration-300 ${
            darkMode ? "bg-zinc-900 border-zinc-800/80 text-zinc-100" : "bg-white border-slate-200/80 text-slate-800"
          }`}>
            <div className={`flex justify-between items-center mb-4 border-b pb-2 ${darkMode ? "border-zinc-800" : "border-slate-100"}`}>
              <h3 className={`text-sm font-bold text-right flex items-center gap-2 ${darkMode ? "text-zinc-200" : "text-slate-800"}`}>
                <History className="w-4 h-4 text-indigo-500" />
                دوماهیک بابەتێن تە
              </h3>
              {history.length > 0 && (
                <button
                  onClick={clearHistory}
                  className="text-[10px] font-bold text-rose-500 hover:text-rose-700 transition-colors"
                >
                  پاککرنەوە
                </button>
              )}
            </div>

            {/* Live Search and History Lists inside Sidebar */}
            <div className="space-y-3 flex-1 overflow-y-auto max-h-[360px] lg:max-h-[none]">
              {searchQuery && (
                <p className="text-[10px] font-bold text-indigo-500 mb-1">ئەنجامێن گەڕیانێ بۆ "{searchQuery}":</p>
              )}
              
              {(searchQuery ? filteredHistory : history).length === 0 ? (
                <div className="flex flex-col items-center justify-center py-8 text-center text-slate-400 h-full">
                  <BookMarked className="w-8 h-8 opacity-20 mb-2" />
                  <p className="text-xs font-bold text-slate-500">مێژوو خاڵیە</p>
                  <p className="text-[10px] max-w-[160px] leading-relaxed mt-0.5">بابەتێن شیکارکری ل ڤێرە دێ دەرکەڤن</p>
                  
                  {/* Default static placeholders shown when list is empty to match style */}
                  <div className="w-full mt-4 space-y-2 text-right opacity-45 pointer-events-none">
                    <div className={`p-2.5 rounded-xl border ${
                      darkMode ? "bg-blue-950/20 border-blue-900/50" : "bg-blue-50/50 border-blue-100/50"
                    }`}>
                      <p className="text-[10px] text-blue-500 font-bold mb-0.5">بیرکاری</p>
                      <p className={`text-xs ${darkMode ? "text-zinc-300" : "text-slate-700"}`}>چارەسەریا هاوکێشێن پلە دوو</p>
                    </div>
                    <div className={`p-2.5 rounded-xl border ${
                      darkMode ? "bg-orange-950/20 border-orange-900/50" : "bg-orange-50/50 border-orange-100/50"
                    }`}>
                      <p className="text-[10px] text-orange-500 font-bold mb-0.5">فیزیا</p>
                      <p className={`text-xs ${darkMode ? "text-zinc-300" : "text-slate-700"}`}>یاسا کێشانا گەردوونی</p>
                    </div>
                  </div>
                </div>
              ) : (
                (searchQuery ? filteredHistory : history).map((item) => (
                  <div
                    key={item.id}
                    onClick={() => handleLoadHistory(item)}
                    className={`p-3 rounded-xl border transition-all duration-200 text-right cursor-pointer hover:scale-[1.01] ${
                      item.subject === "math"
                        ? darkMode ? "bg-blue-950/20 hover:bg-blue-950/40 border-blue-900/50" : "bg-blue-50/50 hover:bg-blue-50 border-blue-100"
                        : item.subject === "physics"
                        ? darkMode ? "bg-orange-950/20 hover:bg-orange-950/40 border-orange-900/50" : "bg-orange-50/50 hover:bg-orange-50 border-orange-100"
                        : darkMode ? "bg-emerald-950/20 hover:bg-emerald-950/40 border-emerald-900/50" : "bg-emerald-50/50 hover:bg-emerald-50 border-emerald-100"
                    }`}
                  >
                    <div className="flex justify-between items-center mb-1">
                      <span className={`text-[9px] font-extrabold ${
                        item.subject === "math" ? "text-blue-500" :
                        item.subject === "physics" ? "text-orange-500" :
                        "text-emerald-500"
                      }`}>
                        {item.subject === "math" ? "بیرکاری" : item.subject === "physics" ? "فیزیا" : "کیمیا"}
                      </span>
                      <span className="text-[8px] text-slate-400 font-medium">
                        {new Date(item.timestamp).toLocaleTimeString("ku-IQ", { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                    <p className={`text-xs font-bold truncate ${darkMode ? "text-zinc-200" : "text-slate-700"}`}>{item.prompt}</p>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Gamified Academics Progress Card matching layout */}
          <div className="bg-gradient-to-br from-indigo-600 to-blue-700 rounded-2xl p-6 text-white shadow-md">
            <p className="text-xs opacity-80 text-right font-medium">پێشکەفتنا ئەکادیمی یا تە</p>
            <h4 className="text-2xl font-black text-right mt-1">
              {history.length > 0 ? `٪${Math.min(100, 45 + history.length * 10)} تەمامبوویە` : "٪١٥ دەستپێکرن"}
            </h4>
            <div className="w-full bg-white/20 h-2 rounded-full mt-4 overflow-hidden">
              <div 
                className="bg-white h-full transition-all duration-700 ease-out" 
                style={{ width: history.length > 0 ? `${Math.min(100, 45 + history.length * 10)}%` : "15%" }}
              ></div>
            </div>
            <p className="text-[10px] opacity-75 text-right mt-3 leading-relaxed">
              {history.length > 0 
                ? `تە ${history.length} بابەتێن زانستی ب زیرەکایەتی شیکارکرینە. بەردەوام بە د فێربوونێ دا!`
                : "پرسیارێن خۆ یێن فیزیا، بیرکاری و کیمیایێ بنووسە بۆ پێشخستنا ئاستێ خۆ."}
            </p>
          </div>
        </aside>

        {/* Right Side: Core Workspace (col-span-12 lg:col-span-9) */}
        <section className="col-span-12 lg:col-span-9 flex flex-col gap-6 order-1 lg:order-2">
          
          {/* Welcome Dashboard Header with Sleek Style */}
          <div className={`rounded-3xl p-6 sm:p-8 shadow-xs border flex flex-col sm:flex-row items-center justify-between gap-6 transition-colors duration-300 ${
            darkMode ? "bg-zinc-900 border-zinc-800/80 text-zinc-100" : "bg-white border-slate-200/80 text-slate-800"
          }`}>
            <div className="flex-1 pr-0 sm:pr-4 text-center sm:text-right">
              <h2 className={`text-2xl sm:text-3xl font-extrabold mb-2 ${darkMode ? "text-white" : "text-slate-800"}`}>بخێر هاتی بۆ زانستێن رەسەن</h2>
              <p className={`text-sm sm:text-base font-medium ${darkMode ? "text-zinc-400" : "text-slate-500"}`}>
                هاریکارێ تە یێ زیرەک و ئەکادیمی بۆ هەموو بابەت و پۆلێن زانستی
              </p>
            </div>
            <div className={`w-24 h-24 sm:w-32 sm:h-24 rounded-2xl flex items-center justify-center transition-colors duration-300 ${
              darkMode ? "bg-zinc-800 text-indigo-400" : "bg-indigo-50/50 text-indigo-600"
            }`}>
              <Sparkles className="w-8 h-8 animate-pulse" />
            </div>
          </div>

          {/* Action Grid Selector / Majestic Visual Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            
            {/* Math Subject Card */}
            <div 
              id="math-card"
              onClick={() => handleCategorySelect("بیرکاری", "math")}
              className={`p-1 rounded-[2rem] shadow-xs border transition-all duration-300 flex flex-col hover:shadow-md cursor-pointer ${
                darkMode ? "bg-zinc-900" : "bg-white"
              } ${
                subject === "math" ? "ring-2 ring-blue-600 border-transparent scale-[1.01]" : darkMode ? "border-zinc-800" : "border-slate-200/80"
              }`}
            >
              <div className="h-28 sm:h-32 bg-gradient-to-b from-blue-500 to-blue-600 rounded-[1.8rem] flex flex-col items-center justify-center text-white">
                <span className="text-4xl font-extrabold mb-1">π</span>
                <span className="font-extrabold text-base">بیرکاری</span>
              </div>
              <div className="p-4 text-center">
                <p className={`text-xs mb-3 line-clamp-2 ${darkMode ? "text-zinc-400" : "text-slate-500"}`}>چارەسەریا هەمی هاوکێشە و بابەتێن بیرکاریێ ب رێکێن سادە</p>
                <button
                  id="math-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCategorySelect("بیرکاری", "math");
                  }}
                  className={`w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    subject === "math" ? "bg-blue-600 text-white" : darkMode ? "bg-blue-950/40 text-blue-400" : "bg-blue-50 text-blue-600"
                  }`}
                >
                  {subject === "math" ? "چالاکە - چارەسەر بکە" : "چارەسەر بکە"}
                </button>
              </div>
            </div>

            {/* Physics Subject Card */}
            <div 
              id="physics-card"
              onClick={() => handleCategorySelect("فیزیا", "physics")}
              className={`p-1 rounded-[2rem] shadow-xs border transition-all duration-300 flex flex-col hover:shadow-md cursor-pointer ${
                darkMode ? "bg-zinc-900" : "bg-white"
              } ${
                subject === "physics" ? "ring-2 ring-orange-500 border-transparent scale-[1.01]" : darkMode ? "border-zinc-800" : "border-slate-200/80"
              }`}
            >
              <div className="h-28 sm:h-32 bg-gradient-to-b from-orange-400 to-orange-500 rounded-[1.8rem] flex flex-col items-center justify-center text-white">
                <span className="text-4xl mb-1">⚡</span>
                <span className="font-extrabold text-base">فیزیا</span>
              </div>
              <div className="p-4 text-center">
                <p className={`text-xs mb-3 line-clamp-2 ${darkMode ? "text-zinc-400" : "text-slate-500"}`}>تێگەهشتن د جیهانا فیزیاێ و یاسایێن وێ یێن بنەرەتی دا</p>
                <button
                  id="physics-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCategorySelect("فیزیا", "physics");
                  }}
                  className={`w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    subject === "physics" ? "bg-orange-500 text-white" : darkMode ? "bg-orange-950/40 text-orange-400" : "bg-orange-50 text-orange-600"
                  }`}
                >
                  {subject === "physics" ? "چالاکە - یاسایان ببینە" : "یاسایان ببینە"}
                </button>
              </div>
            </div>

            {/* Chemistry Subject Card */}
            <div 
              id="chem-card"
              onClick={() => handleCategorySelect("کیمیا", "chemistry")}
              className={`p-1 rounded-[2rem] shadow-xs border transition-all duration-300 flex flex-col hover:shadow-md cursor-pointer ${
                darkMode ? "bg-zinc-900" : "bg-white"
              } ${
                subject === "chemistry" ? "ring-2 ring-emerald-600 border-transparent scale-[1.01]" : darkMode ? "border-zinc-800" : "border-slate-200/80"
              }`}
            >
              <div className="h-28 sm:h-32 bg-gradient-to-b from-emerald-500 to-emerald-600 rounded-[1.8rem] flex flex-col items-center justify-center text-white">
                <span className="text-4xl mb-1">🧪</span>
                <span className="font-extrabold text-base">کیمیا</span>
              </div>
              <div className="p-4 text-center">
                <p className={`text-xs mb-3 line-clamp-2 ${darkMode ? "text-zinc-400" : "text-slate-500"}`}>تێگەهشتنا پێکاتەیێن کیمیایی و هاوکێشێن ئاوێتەیی</p>
                <button
                  id="chem-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleCategorySelect("کیمیا", "chemistry");
                  }}
                  className={`w-full py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    subject === "chemistry" ? "bg-emerald-600 text-white" : darkMode ? "bg-emerald-950/40 text-emerald-400" : "bg-emerald-50 text-emerald-600"
                  }`}
                >
                  {subject === "chemistry" ? "چالاکە - پێکاتییان ببینە" : "پێکاتییان ببینە"}
                </button>
              </div>
            </div>
          </div>

          {/* Core Interactive Solver Workspace Row */}
          <div ref={workspaceRef} className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
            
            {/* Input Solver Panel (lg:col-span-5) */}
            <div className={`lg:col-span-5 rounded-3xl border p-5 shadow-xs flex flex-col gap-4 relative transition-colors duration-300 ${
              darkMode ? "bg-zinc-900 border-zinc-800/80" : "bg-white border-slate-200/80"
            }`}>
              <div className={`flex justify-between items-center pb-2 border-b ${darkMode ? "border-zinc-800" : "border-slate-100"}`}>
                <span className="text-xs font-bold text-slate-500">پێشکێشکرنا کێشەیێ:</span>
                <div className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                  subject === "math" ? darkMode ? "bg-blue-950/40 text-blue-400" : "bg-blue-50 text-blue-700" :
                  subject === "physics" ? darkMode ? "bg-orange-950/40 text-orange-400" : "bg-orange-50 text-orange-700" :
                  darkMode ? "bg-emerald-950/40 text-emerald-400" : "bg-emerald-50 text-emerald-700"
                }`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${
                    subject === "math" ? "bg-blue-600" :
                    subject === "physics" ? "bg-orange-600" :
                    "bg-emerald-600"
                  }`}></span>
                  {subject === "math" ? "بیرکاری" : subject === "physics" ? "فیزیا" : "کیمیا"}
                </div>
              </div>

              {/* Text Area */}
              <div className="relative">
                <textarea
                  id="input-area"
                  ref={textareaRef}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder={
                    subject === "math" ? "بۆ نموونە: هاوکێشەیا بار دوو ٢x² - ٧x + ٣ = ٠ چارەسەر بکە..." :
                    subject === "physics" ? "بۆ نموونە: تەپەیەک لە بەرزایی ٤٥ مەتری بە ئازادی دەکەوێتە خوارێ..." :
                    "بۆ نموونە: هاوکێشەی سووتانی پڕۆپان هەڤسەنگ بکە C3H8 + O2 -> CO2 + H2O..."
                  }
                  className={`w-full min-h-[110px] p-3 rounded-xl border outline-none transition-all duration-200 text-xs leading-relaxed text-right resize-none ${
                    darkMode 
                      ? "bg-zinc-855 border-zinc-750 text-zinc-100 placeholder:text-zinc-500 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10" 
                      : "bg-white border-slate-200 text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-50/50"
                  }`}
                />
              </div>

              {/* Drag & Drop Area / Camera Area */}
              <div className="flex flex-col gap-2">
                <div
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onDrop={handleDrop}
                  className={`border-2 border-dashed rounded-xl p-3 transition-all duration-200 flex flex-col items-center justify-center gap-1.5 cursor-pointer ${
                    isDragging 
                      ? darkMode ? "border-indigo-500 bg-indigo-950/10" : "border-indigo-500 bg-indigo-50/50" 
                      : darkMode ? "border-zinc-800 hover:border-zinc-700 bg-zinc-900/40" : "border-slate-200 hover:border-slate-300 bg-slate-50/40"
                  }`}
                  onClick={() => document.getElementById("file-upload")?.click()}
                >
                  <input
                    id="file-upload"
                    type="file"
                    accept="image/*"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  
                  {image ? (
                    <div className={`w-full flex items-center justify-between p-2 rounded-lg border shadow-xs animate-fade-in ${
                      darkMode ? "bg-zinc-800 border-zinc-700" : "bg-white border-slate-200"
                    }`} onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center gap-2">
                        <img
                          src={`data:${imageMimeType || "image/png"};base64,${image}`}
                          alt="formula snapshot"
                          className={`w-10 h-10 object-cover rounded border ${darkMode ? "border-zinc-700" : "border-slate-100"}`}
                        />
                        <div className="text-right">
                          <p className={`text-[10px] font-bold ${darkMode ? "text-zinc-200" : "text-slate-700"}`}>وێنە هاتە بارکرن</p>
                          <p className="text-[8px] text-slate-400">سیستەم دێ وێنەی خوانێت</p>
                        </div>
                      </div>
                      <button
                        onClick={removeImage}
                        className="p-1.5 rounded bg-rose-50 text-rose-600 hover:bg-rose-100 transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-4 h-4 text-slate-400" />
                      <div className="text-center">
                        <p className={`text-[10px] font-bold ${darkMode ? "text-zinc-200" : "text-slate-700"}`}>کێشەیەک یان وێنەیەک ل بار بکە</p>
                        <p className="text-[8px] text-slate-400 mt-0.5">کلیک بکە یان فایلەک بکێشە ل ڤێرە</p>
                      </div>
                    </>
                  )}
                </div>

                {!image && (
                  <>
                    <input
                      id="camera-upload"
                      type="file"
                      accept="image/*"
                      capture="environment"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => document.getElementById("camera-upload")?.click()}
                      className={`camera-upload w-full py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all duration-200 shadow-sm hover:scale-[1.01] ${
                        darkMode ? "bg-zinc-800 hover:bg-zinc-750 text-white" : "bg-slate-800 hover:bg-slate-900 text-white"
                      }`}
                    >
                      <Camera className="w-4 h-4" />
                      <span>وێنەگرتن ب کامێرێ</span>
                    </button>
                  </>
                )}
              </div>

              {/* Presets Grid */}
              <div className="flex flex-col gap-1.5">
                <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                  <BookOpen className="w-3 h-3 text-indigo-500" />
                  باشترین نموونێن بەرهەڤکری:
                </span>
                <div className="flex flex-col gap-1 max-h-[110px] overflow-y-auto pr-1">
                  {getPresets().map((preset) => (
                    <button
                      key={preset.id}
                      onClick={() => handlePresetSelect(preset)}
                      className={`text-[10px] font-bold p-2 text-right rounded-lg truncate block transition-colors ${
                        darkMode 
                          ? "bg-zinc-850 hover:bg-zinc-800 border border-zinc-750 text-zinc-200" 
                          : "bg-slate-50/80 hover:bg-slate-100 border border-slate-200/60 text-slate-700"
                      }`}
                    >
                      {preset.title}
                    </button>
                  ))}
                </div>
              </div>

              {/* Keyboard inputs */}
              <div className={`border-t pt-3 flex flex-col gap-2 ${darkMode ? "border-zinc-800" : "border-slate-100"}`}>
                <span className="text-[10px] font-bold text-slate-400 flex items-center gap-1">
                  <Info className="w-3 h-3 text-indigo-500" />
                  هاریکارێن نڤیسینێ و هاولاتی:
                </span>

                {subject === "math" && (
                  <div className={`flex flex-wrap gap-1 p-2 rounded-xl border max-h-[110px] overflow-y-auto ${
                    darkMode ? "bg-zinc-950 border-zinc-800/80" : "bg-slate-50 border-slate-100"
                  }`}>
                    {MATH_KEYPAD_SYMBOLS.map((symbol) => (
                      <button
                        key={symbol}
                        onClick={() => insertSymbol(symbol)}
                        className={`math-symbol-btn text-[10px] font-bold px-2 py-1 rounded border transition-all cursor-pointer shadow-xs ${
                          darkMode 
                            ? "bg-zinc-900 border-zinc-750 text-zinc-100 hover:border-indigo-500 hover:text-indigo-400" 
                            : "bg-white border-slate-200 text-slate-700 hover:border-indigo-500 hover:text-indigo-600"
                        }`}
                      >
                        {symbol}
                      </button>
                    ))}
                  </div>
                )}

                {subject === "physics" && (
                  <div className={`grid grid-cols-1 gap-1.5 p-2 rounded-xl border max-h-[110px] overflow-y-auto ${
                    darkMode ? "bg-zinc-950 border-zinc-800/80" : "bg-slate-50 border-slate-100"
                  }`}>
                    {PHYSICAL_CONSTANTS.map((c) => (
                      <div
                        key={c.symbol}
                        className={`flex items-center justify-between border p-1.5 rounded-lg text-[9px] ${
                          darkMode ? "bg-zinc-900 border-zinc-800" : "bg-white border-slate-200/80"
                        }`}
                      >
                        <div className="text-right leading-none">
                          <p className={`font-bold ${darkMode ? "text-zinc-200" : "text-slate-700"}`}>{c.name}</p>
                          <p className="text-[8px] text-slate-400 mt-0.5">{c.value} {c.unit}</p>
                        </div>
                        <button
                          onClick={() => insertSymbol(` ${c.value} `)}
                          className={`px-2 py-0.5 rounded font-black transition-colors ${
                            darkMode ? "bg-orange-950/40 hover:bg-orange-950/60 text-orange-400" : "bg-orange-50 hover:bg-orange-100 text-orange-700"
                          }`}
                        >
                          {c.symbol}
                        </button>
                      </div>
                    ))}
                  </div>
                )}

                {subject === "chemistry" && (
                  <div className={`flex flex-wrap gap-1 p-2 rounded-xl border max-h-[110px] overflow-y-auto ${
                    darkMode ? "bg-zinc-950 border-zinc-800/80" : "bg-slate-50 border-slate-100"
                  }`}>
                    {CHEMICAL_ELEMENTS.map((elem) => (
                      <div
                        key={elem.symbol}
                        className={`group relative flex flex-col items-center border px-1.5 py-1 rounded text-center cursor-pointer hover:border-emerald-500 transition-all ${
                          darkMode ? "bg-zinc-900 border-zinc-850" : "bg-white border-slate-200"
                        }`}
                        onClick={() => insertSymbol(elem.symbol)}
                      >
                        <span className={`font-extrabold text-[10px] ${darkMode ? "text-zinc-200" : "text-slate-800"}`}>{elem.symbol}</span>
                        <span className="text-[7px] text-slate-400 font-semibold">{elem.arabicName}</span>
                        
                        <div className="hidden group-hover:flex absolute bottom-full mb-1 bg-slate-900 text-white p-1.5 rounded text-left text-[8px] whitespace-nowrap z-50 shadow-md flex-col gap-0.5 pointer-events-none">
                          <p className="font-bold text-emerald-400">{elem.name}</p>
                          <p>بارستە: {elem.atomicMass}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Action solve button with design gradient shadow matching subject */}
              <button
                id="solve-submit-btn"
                onClick={handleSolve}
                disabled={loading}
                className={`w-full py-3.5 rounded-xl text-xs sm:text-sm font-extrabold text-white flex items-center justify-center gap-2 transition-all duration-300 shadow-md ${
                  loading
                    ? "bg-slate-400 cursor-not-allowed"
                    : subject === "math" ? `bg-blue-600 hover:bg-blue-700 hover:scale-[1.01] ${darkMode ? "shadow-none" : "shadow-blue-100"}` :
                      subject === "physics" ? `bg-orange-500 hover:bg-orange-600 hover:scale-[1.01] ${darkMode ? "shadow-none" : "shadow-orange-100"}` :
                      `bg-emerald-600 hover:bg-emerald-700 hover:scale-[1.01] ${darkMode ? "shadow-none" : "shadow-emerald-100"}`
                }`}
              >
                {loading ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    <span>شیکارکرن بەردەوامە...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>چارەسەر بکە ب ژیرییا دەستکرد</span>
                  </>
                )}
              </button>
            </div>

            {/* Results Solver Panel & Conversations (lg:col-span-7) */}
            <div className="lg:col-span-7 flex flex-col gap-4">
              
              <AnimatePresence mode="wait">
                
                {/* 1. Explainer block when no solution exists */}
                {!solution && !loading && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    className={`rounded-3xl border p-8 text-center flex flex-col items-center justify-center min-h-[350px] transition-colors duration-300 ${
                      darkMode ? "bg-zinc-900 border-zinc-800/80 text-zinc-100" : "bg-white border-slate-200/80 text-slate-800"
                    }`}
                  >
                    <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-white mb-4 shadow-md ${
                      subject === "math" ? darkMode ? "bg-blue-950/40 text-blue-400" : "bg-blue-50 text-blue-600" :
                      subject === "physics" ? darkMode ? "bg-orange-950/40 text-orange-400" : "bg-orange-50 text-orange-600" :
                      darkMode ? "bg-emerald-950/40 text-emerald-400" : "bg-emerald-50 text-emerald-600"
                    }`}>
                      {subject === "math" ? <Calculator className="w-7 h-7" /> :
                       subject === "physics" ? <Atom className="w-7 h-7" /> :
                       <Beaker className="w-7 h-7" />}
                    </div>

                    <h2 className={`text-lg font-extrabold mb-2 ${darkMode ? "text-zinc-100" : "text-slate-800"}`}>پرسیارێ ب نڤیسە یان وێنە بکە</h2>
                    <p className={`max-w-xs text-xs leading-relaxed mb-6 ${darkMode ? "text-zinc-400" : "text-slate-500"}`}>
                      ژیرییا دەستکرد یا زانستێن رەسەن دێ کێشەیێن تە پێنگاڤ ب پێنگاڤ چارەسەر کەت و شلوڤە کەت.
                    </p>

                    <div className="grid grid-cols-3 gap-3 w-full">
                      <div className={`p-2 rounded-xl border flex flex-col items-center ${
                        darkMode ? "bg-zinc-950 border-zinc-850" : "bg-slate-50 border-slate-100"
                      }`}>
                        <span className="text-sm font-bold text-blue-500">١٠٠٪</span>
                        <span className="text-[9px] font-bold text-slate-400">هەنگاو بە هەنگاو</span>
                      </div>
                      <div className={`p-2 rounded-xl border flex flex-col items-center ${
                        darkMode ? "bg-zinc-950 border-zinc-850" : "bg-slate-50 border-slate-100"
                      }`}>
                        <CheckCircle className="w-4 h-4 text-emerald-500 mb-1" />
                        <span className="text-[9px] font-bold text-slate-400">شیکاریا وێنەیان</span>
                      </div>
                      <div className={`p-2 rounded-xl border flex flex-col items-center ${
                        darkMode ? "bg-zinc-950 border-zinc-850" : "bg-slate-50 border-slate-100"
                      }`}>
                        <MessageCircle className="w-4 h-4 text-orange-400 mb-1" />
                        <span className="text-[9px] font-bold text-slate-400">گفتوگۆیا تێگەهشتنێ</span>
                      </div>
                    </div>
                  </motion.div>
                )}

                {/* 2. Loading placeholder screen */}
                {loading && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className={`rounded-3xl border p-8 flex flex-col items-center justify-center min-h-[350px] transition-colors duration-300 ${
                      darkMode ? "bg-zinc-900 border-zinc-800/80 text-zinc-100" : "bg-white border-slate-200/80 text-slate-800"
                    }`}
                  >
                    <div className="relative mb-4">
                      <div className={`w-12 h-12 rounded-full border-3 ${
                        subject === "math" ? "border-blue-100/30 border-t-blue-500" :
                        subject === "physics" ? "border-orange-100/30 border-t-orange-500" :
                        "border-emerald-100/30 border-t-emerald-600"
                      } animate-spin`}></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Sparkles className={`w-4 h-4 animate-pulse ${
                          subject === "math" ? "text-blue-500" :
                          subject === "physics" ? "text-orange-500" :
                          "text-emerald-500"
                        }`} />
                      </div>
                    </div>

                    <h3 className={`text-sm font-bold mb-1 ${darkMode ? "text-zinc-200" : "text-slate-800"}`}>ئەز دێ پرسیارا تە چارەسەر کەم...</h3>
                    <p className="text-slate-400 text-[10px] text-center max-w-xs leading-relaxed">
                      ژیرییا دەستکرد دێ هاوکێشەیان و لێکدانەوا زانستی کەت، هیڤییە کێمەکێ چاڤەرێ بە...
                    </p>
                  </motion.div>
                )}

                {/* 3. Output Solver Solution Box */}
                {solution && !loading && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.99 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex flex-col gap-4"
                  >
                    {/* Upper control header with action icons matching design bar layout */}
                    <div className={`rounded-2xl border p-3 flex items-center justify-between shadow-xs transition-colors duration-300 ${
                      darkMode ? "bg-zinc-900 border-zinc-800/80" : "bg-white border-slate-200/80"
                    }`}>
                      <span className="text-[10px] font-extrabold text-slate-400 mr-2">چارەسەری و پێزانین:</span>
                      
                      <div className="flex gap-2">
                        {/* Audio Synthesizer Button */}
                        <button
                          onClick={handleSpeak}
                          className={`p-2 rounded-xl border text-[10px] font-bold flex items-center gap-1.5 transition-all ${
                            speaking
                              ? "bg-rose-50 border-rose-200 text-rose-600 hover:bg-rose-100"
                              : darkMode 
                              ? "bg-zinc-800 border-zinc-700 text-zinc-300 hover:bg-zinc-700" 
                              : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                          }`}
                        >
                          {speaking ? <VolumeX className="w-3.5 h-3.5 animate-bounce" /> : <Volume2 className="w-3.5 h-3.5" />}
                          <span>{speaking ? "راوستاندن" : "خوێندنەوە"}</span>
                        </button>

                        {/* Copy Clipboard Button */}
                        <button
                          onClick={handleCopy}
                          className={`p-2 rounded-xl border text-[10px] font-bold flex items-center gap-1.5 transition-colors ${
                            darkMode 
                              ? "border-zinc-700 bg-zinc-800 text-zinc-300 hover:bg-zinc-700" 
                              : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"
                          }`}
                        >
                          {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                          <span>{copied ? "کۆپی کرا!" : "کۆپیکردن"}</span>
                        </button>
                      </div>
                    </div>

                    {/* Rich text solutions display wrapper */}
                    <div className={`rounded-3xl border p-6 shadow-xs max-h-[420px] overflow-y-auto transition-colors duration-300 ${
                      darkMode ? "bg-zinc-900 border-zinc-800/80 text-zinc-100" : "bg-white border-slate-200/80 text-slate-800"
                    }`}>
                      <div className="markdown-body text-right">
                        <ReactMarkdown>{solution}</ReactMarkdown>
                      </div>
                    </div>

                    {/* Micro-learning follow up conversation */}
                    <div className={`rounded-3xl border p-5 shadow-xs flex flex-col gap-3 transition-colors duration-300 ${
                      darkMode ? "bg-zinc-900 border-zinc-800/80" : "bg-white border-slate-200"
                    }`}>
                      <div className={`flex items-center gap-2 font-extrabold text-xs border-b pb-2 ${
                        darkMode ? "text-zinc-200 border-zinc-800" : "text-slate-800 border-slate-100"
                      }`}>
                        <MessageCircle className="w-4 h-4 text-indigo-500" />
                        <span>گەنگەشە و پرسیارێن زێدەتر ل سەر ڤێ بەرسڤێ:</span>
                      </div>

                      {chatHistory.length > 0 && (
                        <div className={`flex flex-col gap-2.5 max-h-[180px] overflow-y-auto mb-1 p-2 rounded-2xl border ${
                          darkMode ? "bg-zinc-950 border-zinc-850" : "bg-slate-50 border-slate-150"
                        }`}>
                          {chatHistory.map((msg, idx) => (
                            <div
                              key={idx}
                              className={`flex flex-col max-w-[85%] rounded-2xl p-2.5 text-xs leading-relaxed ${
                                msg.role === "user"
                                  ? "bg-indigo-600 text-white mr-auto rounded-tl-none text-left"
                                  : darkMode
                                  ? "bg-zinc-900 border border-zinc-800 text-zinc-200 ml-auto rounded-tr-none text-right"
                                  : "bg-white border border-slate-200 text-slate-800 ml-auto rounded-tr-none text-right"
                              }`}
                            >
                              <span className="font-extrabold text-[9px] opacity-75 mb-0.5">
                                {msg.role === "user" ? "قوتابی (تە)" : "هاریکارێ زانستی"}
                              </span>
                              <div className={msg.role === "assistant" ? "markdown-body" : ""}>
                                {msg.role === "assistant" ? (
                                  <ReactMarkdown>{msg.text}</ReactMarkdown>
                                ) : (
                                  <p>{msg.text}</p>
                                )}
                              </div>
                            </div>
                          ))}
                          {chatLoading && (
                            <div className={`rounded-2xl rounded-tr-none p-2.5 text-xs ml-auto max-w-[80%] flex items-center gap-1.5 ${
                              darkMode ? "bg-zinc-900 border border-zinc-800 text-zinc-200" : "bg-white border-slate-200 text-slate-800"
                            }`}>
                              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-100"></div>
                              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-200"></div>
                            </div>
                          )}
                          <div ref={chatEndRef} />
                        </div>
                      )}

                      <div className="flex gap-2">
                        <input
                          id="followup-input"
                          type="text"
                          value={followUpText}
                          onChange={(e) => setFollowUpText(e.target.value)}
                          onKeyDown={(e) => e.key === "Enter" && handleFollowUp()}
                          placeholder="پرسیارەکا دی بکە یان داخوازا شلوڤەکرنا زێدەتر بکە..."
                          className={`flex-1 px-3 py-2.5 rounded-xl border outline-none text-[11px] ${
                            darkMode 
                              ? "bg-zinc-850 border-zinc-750 text-zinc-100 placeholder:text-zinc-500 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10" 
                              : "bg-white border-slate-200 text-slate-800 placeholder:text-slate-400 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-50/50"
                          }`}
                        />
                        <button
                          id="followup-submit-btn"
                          onClick={handleFollowUp}
                          className="px-3.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl transition-colors flex items-center justify-center shadow-xs"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </section>
      </main>

      {/* Sleek Design Footer Info matching design block exactly */}
      <footer className={`h-14 border-t px-4 sm:px-8 flex flex-col sm:flex-row items-center justify-between text-[11px] text-slate-400 gap-2 sm:gap-0 mt-8 py-3 sm:py-0 transition-colors duration-300 ${
        darkMode ? "bg-zinc-900 border-zinc-800/80" : "bg-white border-slate-200"
      }`}>
        <div>وەشان: ١.٠.٢</div>
        <div className={`flex gap-4 font-semibold ${darkMode ? "text-zinc-400" : "text-slate-500"}`}>
          <span className="cursor-pointer hover:text-indigo-400">رێنمایی</span>
          <span className="cursor-pointer hover:text-indigo-400">پەیوەندی</span>
          <span className="cursor-pointer hover:text-indigo-400">دەربارەی مە</span>
        </div>
        <div>© ٢٠٢٦ زانستێن رەسەن. هەمی ماف پاراستینە.</div>
      </footer>
    </div>
  );
}
