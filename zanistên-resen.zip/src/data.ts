export interface Preset {
  id: string;
  title: string;
  prompt: string;
}

export interface PhysicalConstant {
  name: string;
  symbol: string;
  value: string;
  unit: string;
}

export interface ChemicalElement {
  symbol: string;
  name: string;
  arabicName: string;
  atomicNumber: number;
  atomicMass: number;
  group: string;
}

export const MATH_PRESETS: Preset[] = [
  {
    id: "math-1",
    title: "شیکارکرنا هاوکێشەیا بار دوو (Quadratic Equation)",
    prompt: "هیڤییە هاوکێشەیا 2x^2 - 7x + 3 = 0 شیکار بکە و پێنگاڤێن چارەسەریێ دیار بکە.",
  },
  {
    id: "math-2",
    title: "دیتنا داتاشراوا دالەیێ (Find Derivative)",
    prompt: "داتاشراوا (Derivative) ڤێ دالەیێ دەستنیشان بکە: f(x) = 3x^3 - 5x + 12 ب هەموو پێنگاڤان ڤە.",
  },
  {
    id: "math-3",
    title: "هەژمارکرنا تەواوکاریێ (Evaluate Integral)",
    prompt: "تەواوکاریا نەدیار (Indefinite Integral) بۆ ڤێ دەربڕینێ پەیدا بکە: \int (4x^3 - 6x^2 + 2) dx",
  },
];

export const PHYSICS_PRESETS: Preset[] = [
  {
    id: "phys-1",
    title: "کێشەیا کەتنا ئازاد (Free Fall Kinematics)",
    prompt: "تەپەک ژ بلنداهیا 45 مەتری ب ئازادی دکەڤیتە خوارێ. ئەگەر تاودانا کێشکردنێ g = 9.8 m/s^2 بیت، چەند دەم دێ چیت هەتا بگەهیتە سەر ئەردی؟ خێراییا وێ د دەمێ گەهشتنا سەر ئەردی دا دێ چەند بیت؟",
  },
  {
    id: "phys-2",
    title: "یاسای ئۆم بۆ خولا کارەبایی (Ohm's Law)",
    prompt: "ئەگەر سەرچاوەکێ ڤۆڵتیێ یێ 12V هاتبیتە گرێدان ب بەرگرییەکا 4 Ohm ڤە، تەزوویا کارەبایی (Current) دێ چەند بیت؟ وزەیا بەفێڕۆچووی د بەرگریێ دا دێ چەند بیت؟",
  },
  {
    id: "phys-3",
    title: "یاسای کێشکردنا گەردوونی (Universal Gravitation)",
    prompt: "یاسای کێشکردنا گەردوونی یا نیوتنی روون بکە و هاوکێشەیا وێ شلوڤە بکە. هێزا راکێشانێ د ناڤبەرا دوو تەنان دا یێن کو بارستاییا وان 100 کگم بیت و دووراتییا ناڤبەرا وان 2 مەتر بیت دێ چەند بیت؟",
  },
];

export const CHEMISTRY_PRESETS: Preset[] = [
  {
    id: "chem-1",
    title: "هەڤسەنگکرنا هاوکێشەیا کیمیایی (Balance Equation)",
    prompt: "هیڤییە هاوکێشەیا سووتنا پڕۆپانی هەڤسەنگ (Balance) بکە: C3H8 + O2 -> CO2 + H2O و کارلێکرنێ شلوڤە بکە.",
  },
  {
    id: "chem-2",
    title: "هەژمارکرنا مۆڵ و بارستاییێ (Mole & Mass Calculation)",
    prompt: "چەند مۆڵ د ناڤ 180 گرامێن ئاڤا پەتیدا (H2O) هەنە؟ بارستەیا گەردی یا ئاڤێ 18 g/molە. ژمارەیا گەردیلەیان ژی پەیدا بکە ب بکارئینانا ژمارەیا ئەڤۆگادرۆ.",
  },
  {
    id: "chem-3",
    title: "کارلێکرنا ترش و تفتان (Acid-Base Neutralization)",
    prompt: "چ دێ چێبیت دەما ترشا هایدرۆکلۆریک (HCl) دگەل سۆدیۆم هایدرۆکسایدی (NaOH) کارلێکێ دکەت؟ هاوکێشەیا کیمیایی ب دروستی بنڤیسە و ناڤێ خوێیا بەرهەمهاتی بێژە.",
  },
];

export const MATH_KEYPAD_SYMBOLS = [
  "x", "y", "f(x)", "=", "+", "-", "*", "/", "√", "^2", "π", "θ", "Δ", "∫", "dy/dx", "lim", "∞", "sin", "cos", "tan", "log", "ln", "±", "(", ")"
];

export const PHYSICAL_CONSTANTS: PhysicalConstant[] = [
  { name: "تاودانی کێشکردنی زەوی", symbol: "g", value: "9.81", unit: "m/s²" },
  { name: "خێرایی ڕووناکی لە بۆشاییدا", symbol: "c", value: "3.00 × 10⁸", unit: "m/s" },
  { name: "کۆنتراکتی کێشکردنی گشتی", symbol: "G", value: "6.67 × 10⁻¹¹", unit: "N·m²/kg²" },
  { name: "جێگیری پلانک", symbol: "h", value: "6.63 × 10⁻³⁴", unit: "J·s" },
  { name: "بارگەی ئەلەکترۆن", symbol: "e", value: "1.60 × 10⁻¹⁹", unit: "C" },
  { name: "جێگیری گازە تەواوەکان", symbol: "R", value: "8.31", unit: "J/(mol·K)" },
  { name: "ژمارەی ئەڤۆگادرۆ", symbol: "N_A", value: "6.02 × 10²³", unit: "mol⁻¹" },
];

export const CHEMICAL_ELEMENTS: ChemicalElement[] = [
  { symbol: "H", name: "Hydrogen", arabicName: "هایدرۆجین", atomicNumber: 1, atomicMass: 1.008, group: "نامەتەڵ" },
  { symbol: "He", name: "Helium", arabicName: "هیلیۆم", atomicNumber: 2, atomicMass: 4.002, group: "گازی خانەدان" },
  { symbol: "Li", name: "Lithium", arabicName: "لیسیۆم", atomicNumber: 3, atomicMass: 6.94, group: "مەتەڵی تفت" },
  { symbol: "Be", name: "Beryllium", arabicName: "بەریلیۆم", atomicNumber: 4, atomicMass: 9.012, group: "مەتەڵی تفتی زەوی" },
  { symbol: "C", name: "Carbon", arabicName: "کاربۆن", atomicNumber: 6, atomicMass: 12.011, group: "نامەتەڵ" },
  { symbol: "N", name: "Nitrogen", arabicName: "نۆترۆجین", atomicNumber: 7, atomicMass: 14.007, group: "نامەتەڵ" },
  { symbol: "O", name: "Oxygen", arabicName: "ئۆکسجین", atomicNumber: 8, atomicMass: 15.999, group: "نامەتەڵ" },
  { symbol: "F", name: "Fluorine", arabicName: "فلۆر", atomicNumber: 9, atomicMass: 18.998, group: "هالۆجین" },
  { symbol: "Ne", name: "Neon", arabicName: "نیۆن", atomicNumber: 10, atomicMass: 20.18, group: "گازی خانەدان" },
  { symbol: "Na", name: "Sodium", arabicName: "سۆدیۆم", atomicNumber: 11, atomicMass: 22.99, group: "مەتەڵی تفت" },
  { symbol: "Mg", name: "Magnesium", arabicName: "ماگنیسیۆم", atomicNumber: 12, atomicMass: 24.305, group: "مەتەڵی تفتی زەوی" },
  { symbol: "Al", name: "Aluminum", arabicName: "ئەلۆمینیۆم", atomicNumber: 13, atomicMass: 26.982, group: "مەتەڵی پۆست-ئینتقالی" },
  { symbol: "Si", name: "Silicon", arabicName: "سیلیکۆن", atomicNumber: 14, atomicMass: 28.085, group: "شیوە مەتەڵ" },
  { symbol: "P", name: "Phosphorus", arabicName: "فۆسفۆر", atomicNumber: 15, atomicMass: 30.974, group: "نامەتەڵ" },
  { symbol: "S", name: "Sulfur", arabicName: "کبرێت", atomicNumber: 16, atomicMass: 32.06, group: "نامەتەڵ" },
  { symbol: "Cl", name: "Chlorine", arabicName: "کلۆر", atomicNumber: 17, atomicMass: 35.45, group: "هالۆجین" },
  { symbol: "K", name: "Potassium", arabicName: "پۆتاسیۆم", atomicNumber: 19, atomicMass: 39.098, group: "مەتەڵی تفت" },
  { symbol: "Ca", name: "Calcium", arabicName: "کالیسیۆم", atomicNumber: 20, atomicMass: 40.078, group: "مەتەڵی تفتی زەوی" },
  { symbol: "Fe", name: "Iron", arabicName: "ئاسن", atomicNumber: 26, atomicMass: 55.845, group: "مەتەڵی ئینتقالی" },
  { symbol: "Cu", name: "Copper", arabicName: "مس", atomicNumber: 29, atomicMass: 63.546, group: "مەتەڵی ئینتقالی" },
];
